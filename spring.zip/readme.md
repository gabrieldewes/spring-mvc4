#Some setup information :).

##Spring Security Setup
In **SecurityConfiguration** you should setup your protected urls. After that, you should change your **UserDetailsServiceDAO** class and use a valid HQL query to load information about your users.
  	
##Spring JPA Setup
In JPAConfiguration class you must setup your database name, login and password.
  	

